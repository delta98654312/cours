import etoilecraft.*;


public class test {
    public static void main(String[] arg) {
        Marine perso1 = new Marine();
        Flammeur perso2 = new Flammeur(100,40,500000);
        Cuirasse perso3 = new Cuirasse();

        System.out.println("Points de vie Marine : " + perso1.getPointsDeVie());
        System.out.println("Points de vie Flammeur : " + perso2.getPointsDeVie());
        System.out.println("Points de vie Cuirasse : " + perso3.getPointsDeVie());

        System.out.println("Cuirasse est volante ? " + perso3.estVolante());

        System.out.println("Marine attaque Flammeur : " + perso1.attaquer(perso2));
        System.out.println("Flammeur attaque Cuirasse : " + perso2.attaquer(perso3));

        System.out.println("Points de vie Flammeur après attaque : " + perso2.getPointsDeVie());
        System.out.println("Points de vie Cuirasse après attaque : " + perso3.getPointsDeVie());
        
        
        System.out.println(perso2.attaquer(perso1));
        System.out.println("Points de vie marine après attaque : " + perso1.getPointsDeVie());
    }
}
