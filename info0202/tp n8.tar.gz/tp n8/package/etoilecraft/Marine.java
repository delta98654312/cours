package etoilecraft;

public class Marine extends UniteTerran {
	public Marine(){
		super();
	}
	
	public Marine(double v, int a, double p){
		super(v,a,p,p);
	}
}
