package etoilecraft;

public abstract class UniteTerran implements IUnite {
    private double pntvie;
    private int pntarmure;
    private double puissancesol;
    private double puissanceair;

    public UniteTerran() {
        this.pntvie = 100;
        this.pntarmure = 20;
        this.puissancesol = 10;
        this.puissanceair = 10;
    }

    public UniteTerran(double v, int a, double ps, double pa) {
        this.pntvie = v;
        
        if (a<=0)
        	this.pntarmure = 1;
        this.pntarmure = a;
        this.puissancesol = ps;
        this.puissanceair = pa;
    }

    public double getPointsDeVie() {
        return pntvie;
    }

    public double getPointsArmure() {
        return pntarmure;
    }

    public double getPuissanceTirSol() {
        return puissancesol;
    }

    public double getPuissanceTirAir() {
        return puissanceair;
    }

    public boolean subirAttaque(double degat) {
        double damage = pntvie - degat / pntarmure;
        pntvie = damage;
        return damage > 0;
    }

    public boolean attaquer(IUnite u) {
        double degats;
        if (u.estVolante()) {
            degats = Math.random() * puissanceair;
        } else {
            degats = Math.random() * puissancesol;
        }
        return !u.subirAttaque(degats);
    }

    public boolean estVolante() {
        return false;
    }
}
