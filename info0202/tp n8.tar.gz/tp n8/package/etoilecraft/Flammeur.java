package etoilecraft;

public class Flammeur extends UniteTerran {
	public Flammeur(){
		super(100,40,40,0);
	}
	
	public Flammeur(double v, int a, double p){
		super(v,a,p,0);
	}
}
