package etoilecraft;

public class Cuirasse extends UniteTerran {
	public Cuirasse(){
		super(100,10,30,10);
	}
	
	public Cuirasse(double v, int a, double ps,double pa){
		double puissancea = pa;
		if (ps<=pa){
			puissancea = 0;
		}
		super(v,a,ps,puissancea);
		
	}
	
    public boolean estVolante() {
        return true;
    }
}
